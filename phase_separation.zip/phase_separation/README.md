# Binodal Phase Separation Growth Simulation

This repository contains a simulation framework for binodal phase separation growth in 2D or 3D voxel environments. The simulation models the nucleation and growth of two distinct phases (A and B) within an initially mixed phase system.

## Features

- Supports both 2D (e.g., 1024x1024) and 3D (e.g., 128x2048x2048) voxel frameworks
- Stochastic nucleation of component A and B-rich phases
- Growth based on Euclidean distance transforms
- Customizable growth rates
- Visualization of phase evolution
- Simulation continues until all mixed phase is consumed

## Dependencies

The package uses the following dependencies (automatically installed via pip):
- numpy
- scipy
- matplotlib
- edt (euclidean-distance-transform-3d)
- tqdm

## Installation

### Development Installation

For development, install the package in editable mode:

```bash
pip install -e .
```

### Regular Installation

To install the package:

```bash
pip install .
```

## Usage

### Command Line Interface

Once installed, you can run the simulation from the command line:

```bash
phase-simulation [arguments]
```

Example:
```bash
phase-simulation --dims 1024 1024 --growth-rate 5.0 --nucleation-prob-a 0.0005 --nucleation-prob-b 0.0005
```

### As a Python Module

```python
from phase_separation.simulation import PhaseSimulation
from phase_separation.visualization import visualize_simulation

# Create a simulation
sim = PhaseSimulation(
    dimensions=[512, 512],
    growth_rate=5.0,
    nucleation_prob_a=0.0003,
    nucleation_prob_b=0.0003
)

# Run simulation steps
while sim.step():
    pass

# Visualize results
visualize_simulation(sim, sim.time_step, output_dir="./output", is_final=True)
```

## Parameters

- `--dims`: Dimensions of the simulation space (2D or 3D)
- `--growth-rate`: Rate of growth for nucleated phases
- `--nucleation-prob-a`: Probability of nucleation for phase A per voxel per timestep
- `--nucleation-prob-b`: Probability of nucleation for phase B per voxel per timestep
- `--max-steps`: Maximum number of simulation steps
- `--seed`: Random seed for reproducibility
- `--visualize`: Enable visualization during simulation
- `--save-interval`: Interval for saving visualization and state data
- `--output`: Output directory for simulation results

## Examples

The `examples` directory contains sample scripts demonstrating both 2D and 3D simulations:

```bash
python -m examples.example
```

## Output

The simulation produces visualization files and final phase distribution data in the specified output directory.
