#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Visualization module for binodal phase separation growth simulation.

This module provides functions to visualize the phase separation simulation.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap

# Phase constants (must match those in simulation.py)
MIXED_PHASE = 0
PHASE_A = 1
PHASE_B = 2

# Custom colormap for visualization
PHASE_COLORS = [(0.8, 0.8, 0.8),  # Mixed phase: Gray
                (1.0, 0.0, 0.0),  # Phase A: Red
                (0.0, 0.0, 1.0)]  # Phase B: Blue
PHASE_CMAP = ListedColormap(PHASE_COLORS)


def visualize_simulation(simulation, step, output_dir='./output', is_final=False):
    """
    Visualize the current state of the simulation.
    
    Args:
        simulation: PhaseSimulation object
        step: Current simulation step
        output_dir: Directory to save visualization output
        is_final: Whether this is the final visualization
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Determine if 2D or 3D visualization is needed
    if len(simulation.dimensions) == 2:
        _visualize_2d(simulation, step, output_dir, is_final)
    elif len(simulation.dimensions) == 3:
        _visualize_3d(simulation, step, output_dir, is_final)
    else:
        raise ValueError(f"Unsupported dimensions: {simulation.dimensions}")


def _visualize_2d(simulation, step, output_dir, is_final):
    """
    Visualize a 2D simulation.
    
    Args:
        simulation: PhaseSimulation object
        step: Current simulation step
        output_dir: Directory to save visualization output
        is_final: Whether this is the final visualization
    """
    # Create figure
    plt.figure(figsize=(10, 10))
    
    # Plot the phase grid
    plt.imshow(simulation.grid, cmap=PHASE_CMAP, interpolation='nearest', vmin=0, vmax=2)
    
    # Add nucleation points if desired (as small markers)
    # for point in simulation.nucleation_points_a:
    #     plt.plot(point[1], point[0], 'ro', markersize=1)
    # for point in simulation.nucleation_points_b:
    #     plt.plot(point[1], point[0], 'bo', markersize=1)
    
    # Add title and labels
    stats = simulation.get_phase_stats()
    plt.title(f"Step {step}: Mixed={stats['mixed_phase_percent']:.1f}%, "
              f"A={stats['phase_a_percent']:.1f}%, "
              f"B={stats['phase_b_percent']:.1f}%")
    plt.colorbar(ticks=[0, 1, 2], label="Phase")
    plt.tight_layout()
    
    # Save figure
    filename = f"phase_step_{step:04d}.png" if not is_final else "phase_final.png"
    plt.savefig(os.path.join(output_dir, filename), dpi=200)
    plt.close()


def _visualize_3d(simulation, step, output_dir, is_final):
    """
    Visualize a 3D simulation using slices.
    
    Args:
        simulation: PhaseSimulation object
        step: Current simulation step
        output_dir: Directory to save visualization output
        is_final: Whether this is the final visualization
    """
    # For 3D, create slices in each dimension
    grid = simulation.grid
    dims = grid.shape
    
    # Create figure with subplots for different slices
    fig, axs = plt.subplots(1, 3, figsize=(18, 6))
    
    # Add title for the whole figure
    stats = simulation.get_phase_stats()
    fig.suptitle(f"Step {step}: Mixed={stats['mixed_phase_percent']:.1f}%, "
                 f"A={stats['phase_a_percent']:.1f}%, "
                 f"B={stats['phase_b_percent']:.1f}%", fontsize=16)
    
    # X-slice (middle of x dimension)
    x_mid = dims[0] // 2
    axs[0].imshow(grid[x_mid, :, :], cmap=PHASE_CMAP, interpolation='nearest', vmin=0, vmax=2)
    axs[0].set_title(f"X-Slice (x={x_mid})")
    
    # Y-slice (middle of y dimension)
    y_mid = dims[1] // 2
    axs[1].imshow(grid[:, y_mid, :], cmap=PHASE_CMAP, interpolation='nearest', vmin=0, vmax=2)
    axs[1].set_title(f"Y-Slice (y={y_mid})")
    
    # Z-slice (middle of z dimension)
    z_mid = dims[2] // 2
    axs[2].imshow(grid[:, :, z_mid], cmap=PHASE_CMAP, interpolation='nearest', vmin=0, vmax=2)
    axs[2].set_title(f"Z-Slice (z={z_mid})")
    
    # Save figure
    plt.tight_layout(rect=[0, 0, 1, 0.95])  # Adjust for suptitle
    filename = f"phase_step_{step:04d}.png" if not is_final else "phase_final.png"
    plt.savefig(os.path.join(output_dir, filename), dpi=200)
    plt.close()


def visualize_phase_evolution(output_dir, filename="phase_evolution.png"):
    """
    Create a visualization of phase evolution over time from saved step images.
    
    Args:
        output_dir: Directory containing step visualizations
        filename: Filename for the evolution plot
    """
    # Find all step images
    step_files = [f for f in os.listdir(output_dir) if f.startswith("phase_step_") and f.endswith(".png")]
    step_files.sort()
    
    if not step_files:
        print("No step files found for evolution visualization")
        return
    
    # Select a subset of steps for visualization (e.g., 9 steps)
    num_steps = min(9, len(step_files))
    step_indices = np.linspace(0, len(step_files)-1, num_steps, dtype=int)
    selected_files = [step_files[i] for i in step_indices]
    
    # Create grid plot
    rows = int(np.ceil(np.sqrt(num_steps)))
    cols = int(np.ceil(num_steps / rows))
    
    plt.figure(figsize=(cols*4, rows*4))
    
    for i, file in enumerate(selected_files):
        plt.subplot(rows, cols, i+1)
        img = plt.imread(os.path.join(output_dir, file))
        plt.imshow(img)
        plt.title(f"Step {i*len(step_files)//(num_steps-1 or 1)}")
        plt.axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, filename), dpi=200)
    plt.close()
