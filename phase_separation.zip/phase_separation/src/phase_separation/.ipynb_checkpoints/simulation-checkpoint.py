#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Simulation module for binodal phase separation growth.

This module implements the core simulation logic for binodal phase separation
growth in a 2D or 3D voxel framework.
"""

import numpy as np
from scipy.ndimage import distance_transform_edt as edt
from tqdm import tqdm

# Phase constants
MIXED_PHASE = 0
PHASE_A = 1
PHASE_B = 2

import warnings
# the following function will be used to help with code to grow the correct amounts of phases
def relative_phase(f1_A, f1_B, c1):
    '''
    Finds the fraction of volume that should consist of Phase A
    Args:
        f1_A (float, between 0 and 1) : fraction of molecular component 1 in phase A
        f1_B (float, between 0 and 1) : fraction of molecular component 1 in phase B
        c1 (float, between 0 and 1) : fraction of total volume that is component 1
    Returns:
        fracA (float) : Fraction of volume that should be occupied by Phase A (between 0 and 1)
    '''
    fracA = (c1 - f1_B) / (f1_A - f1_B)
    if (fracA > 1.) or (fracA < 0.):
        warnings.warn('Your value for fraction of A is outside of 0 and 1. Check that your parameters make sense.')
        return
    return fracA

class PhaseSimulation:
    """
    Class implementing binodal phase separation growth simulation.
    """
    
    def __init__(self, dimensions, growth_rate=5.0, nucleation_prob_a=0.0005, nucleation_prob_b=0.0005, periodic_boundaries=True):
        """
        Initialize the simulation with given parameters.
        
        Args:
            dimensions: List of dimensions for the simulation space (2D or 3D)
            growth_rate: Growth rate for nucleated phases
            nucleation_prob_a: Probability of nucleation for phase A per voxel per timestep
            nucleation_prob_b: Probability of nucleation for phase B per voxel per timestep
            periodic_boundaries: Whether to use periodic boundary conditions (default: True)
        """
        self.dimensions = dimensions
        self.growth_rate = growth_rate
        self.nucleation_prob_a = nucleation_prob_a
        self.nucleation_prob_b = nucleation_prob_b
        self.periodic_boundaries = periodic_boundaries
        
        # Initialize the voxel grid with mixed phase
        self.grid = np.zeros(dimensions, dtype=np.uint8)
        
        # Track nucleation points for visualization
        self.nucleation_points_a = []
        self.nucleation_points_b = []
        
        # Initialize time step counter
        self.time_step = 0
    
    def step(self,stop_mode = 'normal',f1_A = None, f1_B = None, c1 = None):
        """
        Perform one step of the simulation.
        Args:
            stop_mode (string): 'normal' will change the boolean when the mixed phase no longer
            exists, while 'composition' will change the boolean when Phase A hits a certain threshold
        
        Returns:
            bool: True if mixed phase still exists, False otherwise
        """
        self.time_step += 1
        # Identify mixed phase voxels
        mixed_mask = (self.grid == MIXED_PHASE)

        if stop_mode == 'normal':
        # To terminate if there are no mixed phase voxels
            if not np.any(mixed_mask):
                return False  # No mixed phase left
        elif stop_mode == 'composition': # to terminate when A has reached a certain volume
            compA = (self.grid == PHASE_A)
            fracA_target = relative_phase(f1_A, f1_B, c1)
            if (np.sum(compA ) / np.size(self.grid)) > fracA_target:
                return False # phase A has reached the maximum allowable volume
        
        # Perform nucleation
        self._nucleate(mixed_mask)
        
        # Perform growth
        self._grow()
        
        return True  # Simulation should continue
    
    def _nucleate(self, mixed_mask):
        """
        Nucleate new phase A and phase B points in mixed phase regions.
        
        Args:
            mixed_mask: Boolean mask of mixed phase voxels
        """
        # Get indices of mixed phase voxels
        mixed_indices = np.where(mixed_mask)
        mixed_coords = np.array(mixed_indices).T
        
        if len(mixed_coords) == 0:
            return
        
        # Generate random values for nucleation decisions
        rand_vals_a = np.random.random(len(mixed_coords))
        rand_vals_b = np.random.random(len(mixed_coords))
        
        # Determine nucleation for phase A
        nucleate_a = rand_vals_a < self.nucleation_prob_a
        
        # Determine nucleation for phase B (only in locations where A didn't nucleate)
        nucleate_b = np.logical_and(rand_vals_b < self.nucleation_prob_b, ~nucleate_a)
        
        # Apply nucleation for phase A
        if np.any(nucleate_a):
            nucleation_coords_a = mixed_coords[nucleate_a]
            self.nucleation_points_a.extend(nucleation_coords_a)
            for coord in nucleation_coords_a:
                self.grid[tuple(coord)] = PHASE_A
        
        # Apply nucleation for phase B
        if np.any(nucleate_b):
            nucleation_coords_b = mixed_coords[nucleate_b]
            self.nucleation_points_b.extend(nucleation_coords_b)
            for coord in nucleation_coords_b:
                self.grid[tuple(coord)] = PHASE_B
    
    def _compute_periodic_distance(self, mask):
        """
        Compute the Euclidean distance transform with periodic boundary conditions.
        
        This method implements true periodic boundary conditions by:
        1. Creating a larger grid with the original data replicated in all directions
        2. Running the EDT on this larger grid
        3. Extracting the center portion corresponding to the original domain
        
        Args:
            mask: Boolean mask where True values are the regions to compute distance from.
                  For phase masks, this is typically the inverse of the phase mask (i.e., ~phase_mask)
                  because we want to compute distance FROM the phase boundary.
            
        Returns:
            numpy.ndarray: Distance transform with periodic boundaries applied
        """
        if not self.periodic_boundaries:
            # Use standard EDT if periodic boundaries are disabled
            return edt(mask)
        
        # Get the number of dimensions
        ndim = len(self.dimensions)
        
        # For periodic boundaries to work correctly, we need enough padding to handle
        # cases where the shortest distance is across the boundary
        # Maximum possible distance in a periodic domain is half the domain size
        wrap_sizes = [max(int(self.growth_rate * 3), dim // 2) for dim in self.dimensions]
        
        # Create padding configuration for each dimension
        # Each dimension gets its own appropriate padding size
        pad_width = [(wrap_size, wrap_size) for wrap_size in wrap_sizes]
        
        # Pad the mask with wrapped values from opposite edges
        # mode='wrap' is what implements the periodic boundary condition
        expanded_mask = np.pad(mask, pad_width, mode='wrap')
        
        # Compute EDT on the expanded grid
        # EDT computes distance to nearest True value in the mask
        expanded_distance = edt(expanded_mask)
        
        # Extract the central portion corresponding to the original grid
        # This gives us back the original domain size with the periodic distances
        slices = tuple(slice(wrap_sizes[i], wrap_sizes[i] + self.dimensions[i]) 
                      for i in range(ndim))
        
        return expanded_distance[slices]
    
    def _grow(self):
        """
        Grow existing phases using Euclidean distance transform.
        """
        # Create binary masks for existing phases
        phase_a_mask = (self.grid == PHASE_A)
        phase_b_mask = (self.grid == PHASE_B)
        
        # Compute EDT for each phase (distance to nearest phase A or B voxel)
        # Use inverted masks to get distance from existing phases
        if np.any(phase_a_mask) or np.any(phase_b_mask):
            # Compute distance transforms for each phase
            if np.any(phase_a_mask):
                # Calculate distance to nearest phase A voxel
                if self.periodic_boundaries:
                    distance_a = self._compute_periodic_distance(~phase_a_mask)
                else:
                    distance_a = edt(~phase_a_mask)
            else:
                distance_a = None
                
            if np.any(phase_b_mask):
                # Calculate distance to nearest phase B voxel
                if self.periodic_boundaries:
                    distance_b = self._compute_periodic_distance(~phase_b_mask)
                else:
                    distance_b = edt(~phase_b_mask)
            else:
                distance_b = None
            
            # Determine growth based on distances and growth rate
            mixed_mask = (self.grid == MIXED_PHASE)
            
            if distance_a is not None and distance_b is not None:
                # Both phases exist, compare distances
                
                # Handle the case where distances are equal at interfaces
                equal_distances = np.logical_and(mixed_mask, 
                                               np.logical_and(distance_a <= self.growth_rate,
                                                              distance_a == distance_b))
                
                # For equal distances, randomly assign to phase A or B
                if np.any(equal_distances):
                    # Generate random mask where True → phase A, False → phase B
                    random_assign = np.random.random(self.dimensions) > 0.5
                    equal_to_a = np.logical_and(equal_distances, random_assign)
                    equal_to_b = np.logical_and(equal_distances, ~random_assign)
                else:
                    equal_to_a = np.zeros_like(mixed_mask)
                    equal_to_b = np.zeros_like(mixed_mask)
                
                # Normal growth for non-equal distances
                growth_mask_a = np.logical_or(
                    np.logical_and(mixed_mask, 
                                  np.logical_and(distance_a <= self.growth_rate,
                                                distance_a < distance_b)),
                    equal_to_a  # Add the randomly assigned equal-distance voxels
                )
                
                growth_mask_b = np.logical_or(
                    np.logical_and(mixed_mask, 
                                  np.logical_and(distance_b <= self.growth_rate,
                                                distance_b < distance_a)),
                    equal_to_b  # Add the randomly assigned equal-distance voxels
                )
                
            elif distance_a is not None:
                # Only phase A exists
                growth_mask_a = np.logical_and(mixed_mask, distance_a <= self.growth_rate)
                growth_mask_b = np.zeros_like(mixed_mask)
            elif distance_b is not None:
                # Only phase B exists
                growth_mask_a = np.zeros_like(mixed_mask)
                growth_mask_b = np.logical_and(mixed_mask, distance_b <= self.growth_rate)
            else:
                # Neither phase exists (shouldn't happen after nucleation)
                return
            
            # Apply growth
            self.grid[growth_mask_a] = PHASE_A
            self.grid[growth_mask_b] = PHASE_B
    
    def get_phase_stats(self):
        """
        Get statistics about the current phase distribution.
        
        Returns:
            dict: Dictionary with phase statistics
        """
        total_voxels = np.prod(self.dimensions)
        mixed_voxels = np.sum(self.grid == MIXED_PHASE)
        phase_a_voxels = np.sum(self.grid == PHASE_A)
        phase_b_voxels = np.sum(self.grid == PHASE_B)
        
        return {
            "time_step": self.time_step,
            "mixed_phase": mixed_voxels,
            "mixed_phase_percent": (mixed_voxels / total_voxels) * 100,
            "phase_a": phase_a_voxels,
            "phase_a_percent": (phase_a_voxels / total_voxels) * 100,
            "phase_b": phase_b_voxels,
            "phase_b_percent": (phase_b_voxels / total_voxels) * 100
        }
    
    def save_state(self, filename):
        """
        Save the current simulation state to a file.
        
        Args:
            filename: Path to save the simulation state
        """
        np.savez_compressed(
            filename,
            grid=self.grid,
            dimensions=self.dimensions,
            time_step=self.time_step,
            growth_rate=self.growth_rate,
            nucleation_prob_a=self.nucleation_prob_a,
            nucleation_prob_b=self.nucleation_prob_b,
            periodic_boundaries=self.periodic_boundaries
        )
    
    @classmethod
    def load_state(cls, filename):
        """
        Load a simulation state from a file.
        
        Args:
            filename: Path to the saved simulation state
            
        Returns:
            PhaseSimulation: Loaded simulation object
        """
        data = np.load(filename)
        
        # Handle the case where older saved files don't have periodic_boundaries parameter
        periodic_boundaries = bool(data['periodic_boundaries']) if 'periodic_boundaries' in data else True
        
        sim = cls(
            dimensions=data['dimensions'],
            growth_rate=float(data['growth_rate']),
            nucleation_prob_a=float(data['nucleation_prob_a']),
            nucleation_prob_b=float(data['nucleation_prob_b']),
            periodic_boundaries=periodic_boundaries
        )
        sim.grid = data['grid']
        sim.time_step = int(data['time_step'])
        return sim
