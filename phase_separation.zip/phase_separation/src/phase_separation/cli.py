#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Command-line interface for the phase separation simulation.
"""

import sys
from phase_separation.main import main

def cli_main():
    """
    Entry point for the command-line interface.
    """
    main()

if __name__ == "__main__":
    sys.exit(cli_main())
