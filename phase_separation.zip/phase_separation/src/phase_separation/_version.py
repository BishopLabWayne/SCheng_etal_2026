#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Version information for the phase_separation package.
"""

version = "0.1.0"
