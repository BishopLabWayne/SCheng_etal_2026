#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Binodal Phase Separation Growth Simulation

This package implements a simulation framework for binodal phase separation growth
in 2D or 3D voxel environments.
"""

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "unknown"

# Import key modules for convenient access
from .simulation import PhaseSimulation
from .visualization import visualize_simulation, visualize_phase_evolution

__all__ = ["PhaseSimulation", "visualize_simulation", "visualize_phase_evolution"]
