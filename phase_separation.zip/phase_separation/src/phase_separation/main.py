#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Binodal Phase Separation Growth Simulation

This script runs a binodal phase separation growth simulation in a 2D or 3D voxel
framework. The simulation models nucleation and growth of two distinct phases.
"""

import argparse
import os
import time
import numpy as np
from phase_separation.simulation import PhaseSimulation
from phase_separation.visualization import visualize_simulation


def parse_args():
    """
    Parse command line arguments for the simulation.
    """
    parser = argparse.ArgumentParser(description='Binodal Phase Separation Growth Simulation')
    
    # Simulation dimensions
    parser.add_argument('--dims', nargs='+', type=int, default=[1024, 1024],
                        help='Dimensions of the simulation space (2D or 3D). Example: --dims 1024 1024 for 2D or --dims 128 2048 2048 for 3D')
    
    # Simulation parameters
    parser.add_argument('--growth-rate', type=float, default=5.0,
                        help='Growth rate for nucleated phases')
    parser.add_argument('--nucleation-prob-a', type=float, default=0.0005,
                        help='Probability of nucleation for phase A per voxel per timestep')
    parser.add_argument('--nucleation-prob-b', type=float, default=0.0005,
                        help='Probability of nucleation for phase B per voxel per timestep')
    parser.add_argument('--max-steps', type=int, default=1000,
                        help='Maximum number of simulation steps')
    parser.add_argument('--seed', type=int, default=None,
                        help='Random seed for reproducibility')
    
    # Output and visualization
    parser.add_argument('--visualize', action='store_true',
                        help='Enable visualization during simulation')
    parser.add_argument('--save-interval', type=int, default=10,
                        help='Interval for saving visualization and state data')
    parser.add_argument('--output', type=str, default='./output',
                        help='Output directory for simulation results')
    
    return parser.parse_args()


def main():
    """
    Main function to run the simulation.
    """
    args = parse_args()
    
    # Set random seed if provided
    if args.seed is not None:
        np.random.seed(args.seed)
    
    # Create output directory if it doesn't exist
    os.makedirs(args.output, exist_ok=True)
    
    # Initialize simulation
    sim = PhaseSimulation(
        dimensions=args.dims,
        growth_rate=args.growth_rate,
        nucleation_prob_a=args.nucleation_prob_a,
        nucleation_prob_b=args.nucleation_prob_b
    )
    
    # Run simulation
    print(f"Starting simulation with dimensions {args.dims}")
    start_time = time.time()
    
    step = 0
    mixed_phase_exists = True
    
    while mixed_phase_exists and step < args.max_steps:
        # Run one simulation step
        mixed_phase_exists = sim.step()
        
        # Visualization and saving if needed
        if args.visualize and step % args.save_interval == 0:
            print(f"Step {step}: {sim.get_phase_stats()}")
            visualize_simulation(sim, step, output_dir=args.output)
        
        step += 1
    
    # Final visualization
    if args.visualize:
        visualize_simulation(sim, step, output_dir=args.output, is_final=True)
    
    # Save final state
    sim.save_state(os.path.join(args.output, f"final_state.npz"))
    
    elapsed_time = time.time() - start_time
    print(f"Simulation completed in {elapsed_time:.2f} seconds")
    print(f"Total steps: {step}")
    print(f"Final state: {sim.get_phase_stats()}")


if __name__ == "__main__":
    main()
