#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Example script demonstrating how to use the binodal phase separation simulation.
"""

import os
import numpy as np
import sys
sys.path.append(os.path.abspath('..'))
sys.path.append('/home/cbishop/GitRepos/phase_separation/phase_separation/src/')
from phase_separation.simulation import PhaseSimulation
from phase_separation.visualization import visualize_simulation, visualize_phase_evolution

# Create output directory
output_dir = "./run1_output"
os.makedirs(output_dir, exist_ok=True)

def run_2d_example():
    """
    Run a 2D simulation example.
    """
    print("Running 2D simulation example...")
    
    # Set parameters
    dims = [2048,2048]  # Smaller dimensions for quick example
    growth_rate = 3.0
    nucleation_prob_a = 0.00001
    nucleation_prob_b = 0.00001
    max_steps = 200
    
    # Create simulation
    sim = PhaseSimulation(
        dimensions=dims,
        growth_rate=growth_rate,
        nucleation_prob_a=nucleation_prob_a,
        nucleation_prob_b=nucleation_prob_b
    )
    
    # Run simulation
    step = 0
    mixed_phase_exists = True
    
    while mixed_phase_exists and step < max_steps:
        # Run one simulation step
        mixed_phase_exists = sim.step()
        
        # Visualization every 10 steps
        if step % 10 == 0:
            print(f"Step {step}: {sim.get_phase_stats()}")
            visualize_simulation(sim, step, output_dir=output_dir)
        
        step += 1
    
    # Final visualization
    visualize_simulation(sim, step, output_dir=output_dir, is_final=True)
    
    # Create evolution visualization
    visualize_phase_evolution(output_dir)
    
    print(f"Simulation complete after {step} steps")
    print(f"Results saved to {os.path.abspath(output_dir)}")

def run_3d_example():
    """
    Run a 3D simulation example.
    """
    print("\nRunning 3D simulation example...")
    
    # Set parameters
    dims = [64, 64, 64]  # Small 3D example
    growth_rate = 4.0
    nucleation_prob_a = 0.0002
    nucleation_prob_b = 0.0002
    max_steps = 100
    
    # Create simulation
    sim = PhaseSimulation(
        dimensions=dims,
        growth_rate=growth_rate,
        nucleation_prob_a=nucleation_prob_a,
        nucleation_prob_b=nucleation_prob_b
    )
    
    # Run simulation
    step = 0
    mixed_phase_exists = True
    
    while mixed_phase_exists and step < max_steps:
        # Run one simulation step
        mixed_phase_exists = sim.step()
        
        # Visualization every 10 steps
        if step % 10 == 0:
            print(f"Step {step}: {sim.get_phase_stats()}")
            visualize_simulation(sim, step, output_dir=f"{output_dir}/3d", is_final=False)
        
        step += 1
    
    # Final visualization
    visualize_simulation(sim, step, output_dir=f"{output_dir}/3d", is_final=True)
    
    print(f"3D Simulation complete after {step} steps")
    print(f"Results saved to {os.path.abspath(output_dir)}/3d")


if __name__ == "__main__":
    # Run examples
    run_2d_example()
    run_3d_example()
